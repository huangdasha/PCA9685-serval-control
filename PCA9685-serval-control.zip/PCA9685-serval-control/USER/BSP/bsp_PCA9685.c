#include "bsp_PCA9685.h"
#include "myiic.h"
#include "delay.h"
#include <math.h>

void PCA9685_Init(float hz,u8 angle)
{
	u32 off = 0;
	IIC_Init();
	PCA9685_Write(PCA_Model,0x00);
	PCA9685_setFreq(hz);
	off = (u32)(145+angle*2.4);
	PCA9685_setPWM(0,0,off);
	PCA9685_setPWM(1,0,off);
	PCA9685_setPWM(2,0,off);
	PCA9685_setPWM(3,0,off);
	PCA9685_setPWM(4,0,off);
	PCA9685_setPWM(5,0,off);
	PCA9685_setPWM(6,0,off);
	PCA9685_setPWM(7,0,off);
	PCA9685_setPWM(8,0,off);
	PCA9685_setPWM(9,0,off);
	PCA9685_setPWM(10,0,off);
	PCA9685_setPWM(11,0,off);
	PCA9685_setPWM(12,0,off);
	PCA9685_setPWM(13,0,off);
	PCA9685_setPWM(14,0,off);
	PCA9685_setPWM(15,0,off);

	delay_ms(100);
	
}

void PCA9685_Init2(float hz,u8 angle)
{
	u32 off = 0;
	IIC_Init();
	PCA9685_Write2(PCA_Model,0x00);
	PCA9685_setFreq2(hz);
	off = (u32)(145+angle*2.4);
	PCA9685_setPWM2(0,0,off);
	PCA9685_setPWM2(1,0,off);
	PCA9685_setPWM2(2,0,off);
	PCA9685_setPWM2(3,0,off);
	PCA9685_setPWM2(4,0,off);
	PCA9685_setPWM2(5,0,off);
	PCA9685_setPWM2(6,0,off);
	PCA9685_setPWM2(7,0,off);
	PCA9685_setPWM2(8,0,off);
	PCA9685_setPWM2(9,0,off);
	PCA9685_setPWM2(10,0,off);
	PCA9685_setPWM2(11,0,off);
	PCA9685_setPWM2(12,0,off);
	PCA9685_setPWM2(13,0,off);
	PCA9685_setPWM2(14,0,off);
	PCA9685_setPWM2(15,0,off);

	delay_ms(100);
	
}

void PCA9685_Init3(float hz,u8 angle)
{
	u32 off = 0;
	IIC_Init();
	PCA9685_Write3(PCA_Model,0x00);
	PCA9685_setFreq3(hz);
	off = (u32)(145+angle*2.4);
	PCA9685_setPWM3(0,0,off);
	PCA9685_setPWM3(1,0,off);
	PCA9685_setPWM3(2,0,off);
	PCA9685_setPWM3(3,0,off);
	PCA9685_setPWM3(4,0,off);
	PCA9685_setPWM3(5,0,off);
	PCA9685_setPWM3(6,0,off);
	PCA9685_setPWM3(7,0,off);
	PCA9685_setPWM3(8,0,off);
	PCA9685_setPWM3(9,0,off);
	PCA9685_setPWM3(10,0,off);
	PCA9685_setPWM3(11,0,off);
	PCA9685_setPWM3(12,0,off);
	PCA9685_setPWM3(13,0,off);
	PCA9685_setPWM3(14,0,off);
	PCA9685_setPWM3(15,0,off);

	delay_ms(100);
	
}


void PCA9685_Write(u8 addr,u8 data)
{
	IIC_Start();
	
	IIC_Send_Byte(PCA_Addr);
	IIC_NAck();
	
	IIC_Send_Byte(addr);
	IIC_NAck();
	
	IIC_Send_Byte(data);
	IIC_NAck();
	
	IIC_Stop();
}

void PCA9685_Write2(u8 addr,u8 data)
{
	IIC_Start();
	
	IIC_Send_Byte(PCA_Addr2);
	IIC_NAck();
	
	IIC_Send_Byte(addr);
	IIC_NAck();
	
	IIC_Send_Byte(data);
	IIC_NAck();
	
	IIC_Stop();
}

void PCA9685_Write3(u8 addr,u8 data)
{
	IIC_Start();
	
	IIC_Send_Byte(PCA_Addr3);
	IIC_NAck();
	
	IIC_Send_Byte(addr);
	IIC_NAck();
	
	IIC_Send_Byte(data);
	IIC_NAck();
	
	IIC_Stop();
}

u8 PCA9685_Read(u8 addr)
{
	u8 data;
	
	IIC_Start();
	
	IIC_Send_Byte(PCA_Addr);
	IIC_NAck();
	
	IIC_Send_Byte(addr);
	IIC_NAck();
	
	IIC_Stop();
	
	delay_us(10);

	
	IIC_Start();

	IIC_Send_Byte(PCA_Addr|0x01);
	IIC_NAck();
	
	data = IIC_Read_Byte(0);
	
	IIC_Stop();
	
	return data;
	
}

u8 PCA9685_Read2(u8 addr)
{
	u8 data;
	
	IIC_Start();
	
	IIC_Send_Byte(PCA_Addr2);
	IIC_NAck();
	
	IIC_Send_Byte(addr);
	IIC_NAck();
	
	IIC_Stop();
	
	delay_us(10);

	
	IIC_Start();

	IIC_Send_Byte(PCA_Addr2|0x01);
	IIC_NAck();
	
	data = IIC_Read_Byte(0);
	
	IIC_Stop();
	
	return data;
	
}

u8 PCA9685_Read3(u8 addr)
{
	u8 data;
	
	IIC_Start();
	
	IIC_Send_Byte(PCA_Addr3);
	IIC_NAck();
	
	IIC_Send_Byte(addr);
	IIC_NAck();
	
	IIC_Stop();
	
	delay_us(10);

	
	IIC_Start();

	IIC_Send_Byte(PCA_Addr3|0x01);
	IIC_NAck();
	
	data = IIC_Read_Byte(0);
	
	IIC_Stop();
	
	return data;
	
}

void PCA9685_setPWM(u8 num,u32 on,u32 off)
{
		IIC_Start();
		
		IIC_Send_Byte(PCA_Addr);
		IIC_Wait_Ack();
		
		IIC_Send_Byte(LED0_ON_L+4*num);
		IIC_Wait_Ack();
		
		IIC_Send_Byte(on&0xFF);
		IIC_Wait_Ack();
		
		IIC_Send_Byte(on>>8);
		IIC_Wait_Ack();
		
		IIC_Send_Byte(off&0xFF);
		IIC_Wait_Ack();
		
		IIC_Send_Byte(off>>8);
		IIC_Wait_Ack();
		
		IIC_Stop();
}

void PCA9685_setPWM2(u8 num,u32 on,u32 off)
{
		IIC_Start();
		
		IIC_Send_Byte(PCA_Addr2);
		IIC_Wait_Ack();
		
		IIC_Send_Byte(LED0_ON_L+4*num);
		IIC_Wait_Ack();
		
		IIC_Send_Byte(on&0xFF);
		IIC_Wait_Ack();
		
		IIC_Send_Byte(on>>8);
		IIC_Wait_Ack();
		
		IIC_Send_Byte(off&0xFF);
		IIC_Wait_Ack();
		
		IIC_Send_Byte(off>>8);
		IIC_Wait_Ack();
		
		IIC_Stop();
}

void PCA9685_setPWM3(u8 num,u32 on,u32 off)
{
		IIC_Start();
		
		IIC_Send_Byte(PCA_Addr3);
		IIC_Wait_Ack();
		
		IIC_Send_Byte(LED0_ON_L+4*num);
		IIC_Wait_Ack();
		
		IIC_Send_Byte(on&0xFF);
		IIC_Wait_Ack();
		
		IIC_Send_Byte(on>>8);
		IIC_Wait_Ack();
		
		IIC_Send_Byte(off&0xFF);
		IIC_Wait_Ack();
		
		IIC_Send_Byte(off>>8);
		IIC_Wait_Ack();
		
		IIC_Stop();
}

void PCA9685_setFreq(float freq)
{
	u8 prescale,oldmode,newmode;
	
	double prescaleval;
	
	// freq *= 0.92;
	prescaleval = 25000000;
	prescaleval /= 4096;
	prescaleval /= freq;
	prescaleval -= 1;
	prescale = floor(prescaleval+0.5f);
	oldmode = PCA9685_Read(PCA_Model);
	
	// ���� pca9685 reset����ΪPCA_Model�Ĵ����ĵ�һλ��1��ʱ�����reset��
	newmode = (oldmode&0x7F)|0x10;
	PCA9685_Write(PCA_Model,newmode);
	
	// ��PCA_Pre�Ĵ�����ַд�����õķ�Ƶֵ��
	PCA9685_Write(PCA_Pre,prescale);
	PCA9685_Write(PCA_Model,oldmode);
	
	// �ָ��豸������ PCA9685
	delay_ms(5);
	PCA9685_Write(PCA_Model,oldmode|0xa1);
}

void PCA9685_setFreq2(float freq)
{
	u8 prescale,oldmode,newmode;
	
	double prescaleval;
	
	// freq *= 0.92;
	prescaleval = 25000000;
	prescaleval /= 4096;
	prescaleval /= freq;
	prescaleval -= 1;
	prescale = floor(prescaleval+0.5f);
	oldmode = PCA9685_Read2(PCA_Model);
	
	// ���� pca9685 reset����ΪPCA_Model�Ĵ����ĵ�һλ��1��ʱ�����reset��
	newmode = (oldmode&0x7F)|0x10;
	PCA9685_Write2(PCA_Model,newmode);
	
	// ��PCA_Pre�Ĵ�����ַд�����õķ�Ƶֵ��
	PCA9685_Write2(PCA_Pre,prescale);
	PCA9685_Write2(PCA_Model,oldmode);
	
	// �ָ��豸������ PCA9685
	delay_ms(5);
	PCA9685_Write2(PCA_Model,oldmode|0xa1);
}

void PCA9685_setFreq3(float freq)
{
	u8 prescale,oldmode,newmode;
	
	double prescaleval;
	
	// freq *= 0.92;
	prescaleval = 25000000;
	prescaleval /= 4096;
	prescaleval /= freq;
	prescaleval -= 1;
	prescale = floor(prescaleval+0.5f);
	oldmode = PCA9685_Read3(PCA_Model);
	
	// ���� pca9685 reset����ΪPCA_Model�Ĵ����ĵ�һλ��1��ʱ�����reset��
	newmode = (oldmode&0x7F)|0x10;
	PCA9685_Write3(PCA_Model,newmode);
	
	// ��PCA_Pre�Ĵ�����ַд�����õķ�Ƶֵ��
	PCA9685_Write3(PCA_Pre,prescale);
	PCA9685_Write3(PCA_Model,oldmode);
	
	// �ָ��豸������ PCA9685
	delay_ms(5);
	PCA9685_Write3(PCA_Model,oldmode|0xa1);
}

void setAngle(u8 num,u8 angle)
{
	u32 off = 0;
	off = (u32)(158+angle*2.2);
	PCA9685_setPWM(num,0,off);
}



